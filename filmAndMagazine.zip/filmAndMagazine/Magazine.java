
package citationmachinetester;

import java.util.ArrayList;
import java.util.HashMap;

public class Magazine extends CitationMachine{
    String articleTitle, pageStart, pageEnd;
    
    public Magazine(HashMap c){
        super( c );
        this.articleTitle = (String)c.get(articleTitle);
        this.pageStart = (String)c.get(pageStart);
        this.pageEnd = (String)c.get(pageEnd);
        
        if(this.articleTitle == null || this.articleTitle == "ArticleTitle"){
            this.articleTitle = "";
        }
        if(this.pageStart == null || this.pageStart == "PageStart"){
            this.pageStart = "";
        }
        if(this.pageEnd == null || this.pageEnd == "PageEnd"){
            this.pageEnd = "";
        }

        if(authorLast != "" || authorLast != null){
            authorLast = authorLast + ".";
        }
        
        if(authorFirst != "" || authorFirst != null){
            authorFirst = authorFirst + "." + '"';
        }
        
        if(articleTitle != "" || articleTitle != null){
            articleTitle = articleTitle + ":  ";
        }
        
        if(pageEnd != "" || pageEnd != null){
            pageEnd = "-" + pageEnd;
        }
        
        
        
        
    }
    
    public String cite(){
        citation = authorLast + authorFirst + articleTitle
                + ": " + pageStart + pageEnd + ".Print.";
        
        return citation;
    }
    
    public String getSimilarMagazine(){
        return null;
    }
    
}
