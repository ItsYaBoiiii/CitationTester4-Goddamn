
package citationmachinetester;

import java.util.HashMap;

public class Film extends CitationMachine{
    String mainPerformers;
    
    public Film ( HashMap c ){
        super( c );
        this.mainPerformers = (String)c.get(mainPerformers);
        
        if (this.mainPerformers == null || this.mainPerformers == "MainPerformers"){
            this.mainPerformers = "";
        }
        
        title = title + " Dir. ";
        
        if(authorLast != "" || authorLast != null){
            authorLast = authorLast + ".";
        }
        
        if(authorFirst != "" || authorFirst != null){
            authorFirst = authorFirst + ".";
        }
        
        if(mainPerformers != "" || mainPerformers != null){
            mainPerformers = "Perf. " + mainPerformers + ".";
        }
        
        
        
        
        
    }
    
    
   
    
    public String cite(){
        citation = title + authorLast + authorFirst + 
                mainPerformers + publishDay
                + publishMonth + publishYear;
                
                return citation;
    }
    
    public String getSimilarFilm(){
        return null;
    }
}
