package citationmachinetester;

import java.util.HashMap;

public class Book extends CitationMachine{
    String cityOfPublication, publisher;
    
    public Book( HashMap c ){
        super(c);
        
        this.publisher = (String)c.get(publisher);

        title = (String)c.get("title");
        if ( title == null || title.equals("Title") )
            title = "";
        else
            title += ". ";
        
        cityOfPublication = (String)c.get("cityOfPublication");
        if ( cityOfPublication == null || cityOfPublication.equals("CityOfPublication") )
            cityOfPublication = "";
        else
            cityOfPublication += ". ";
        
        if(publisher != ""|| publisher != null){
            publisher = publisher + ".,";
        }
        else{
            publisher = "n.p.";
        }

        

            
    }
    
    public void cite(){
        citation = authorLast + authorFirst + title + cityOfPublication 
                + publisher + publishYear + "Print.";
    }
    
}
